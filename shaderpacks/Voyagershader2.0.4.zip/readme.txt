=>Description<=
Here is a text file that you must read if you want to use or modify the Voyager shader 2.0 

The Voyager shader 2.0 works only in 1.16.5 with Optifine HD U G8 minimum and with 1.17+ with Optifine HD U G9 because the shader uses functions 
available only on this version
For the previous version, you will have to wait for the future updates of Optifine unfortunately

Download Optifine :
https://optifine.net/downloads

=>Report bugs<=

If you have a bug related to Voyager shader 2.0, you can report them in my discord in the #bugs channel but first read the pinned message
Discord link : discord.gg/2eyNefx

=>Agreement<=

You can...

-Use the shader to make screenhots or videos

-Use the shader for a modpack

-Modified the shader only for a personal use

-Create a link only if it redirects to the post Curseforge on behalf of Symbiome67 or the post PlanetMinecraft on behalf of SixSeven67

You can not...

-Redistribute the shader, only the Curseforge post on behalf of Symbiome67 and the PlanetMinecraft post on behalf of SixSeven67 are official

-Redistribute a modified version of the shader

-Use monetized shortcut links to the Curseforge post on behalf of Symbiome67 and the PlanetMinecraft post on behalf of SixSeven67